package bank.exceptions;

public class UnsuccessfulBalanceUpdate extends Exception {

}

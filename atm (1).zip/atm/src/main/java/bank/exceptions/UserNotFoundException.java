package bank.exceptions;

public class UserNotFoundException extends Exception {

}

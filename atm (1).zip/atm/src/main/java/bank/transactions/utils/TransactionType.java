package bank.transactions.utils;

public enum TransactionType {
	Withdrawal, Deposit, Transfer
}

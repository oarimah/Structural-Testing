package bank.transactions.utils;

public enum AccountType {
	Chequing, Savings, TFSA, None
}

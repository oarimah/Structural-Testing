package atm.session.transactions;

public class ATMNoTransaction extends ATMTransaction {

	public ATMNoTransaction() {
		super(null);
	}


}

package atm.exceptions;

public class InvalidPinFormatException extends Exception {

}
